"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = handler;
const msal_node_1 = require("@azure/msal-node");
const zod_1 = require("zod");
// =============================================================================
// Configuration from Environment Variables
// =============================================================================
const TURNSTILE_SECRET = process.env.TURNSTILE_SECRET_KEY || '';
const AZURE_TENANT_ID = process.env.AZURE_TENANT_ID || '';
const AZURE_CLIENT_ID = process.env.AZURE_CLIENT_ID || '';
const AZURE_CLIENT_SECRET = process.env.AZURE_CLIENT_SECRET || '';
const SHAREPOINT_SITE_ID = process.env.SHAREPOINT_SITE_ID || '';
const SHAREPOINT_LIST_ID = process.env.SHAREPOINT_LIST_ID || '';
const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || 'https://www.hybe.tech';
// =============================================================================
// Input Validation Schema
// =============================================================================
const subscribeSchema = zod_1.z.object({
    email: zod_1.z
        .string()
        .email('Please enter a valid email address')
        .max(254, 'Email address too long')
        .transform((e) => e.toLowerCase().trim()),
    turnstileToken: zod_1.z.string().min(1, 'Verification required'),
    source: zod_1.z.string().optional().default('Website Footer'),
});
// =============================================================================
// CORS Headers
// =============================================================================
const corsHeaders = {
    'Access-Control-Allow-Origin': ALLOWED_ORIGIN,
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Content-Type': 'application/json',
};
// =============================================================================
// Helper Functions
// =============================================================================
/**
 * Get HTTP method - supports both REST API (v1) and HTTP API (v2) event formats
 */
function getHttpMethod(event) {
    // HTTP API format (API Gateway v2)
    const httpApiMethod = event.requestContext?.http?.method;
    if (httpApiMethod) {
        return httpApiMethod;
    }
    // REST API format (API Gateway v1)
    return event.httpMethod || '';
}
/**
 * Get client IP address from various sources
 */
function getClientIp(event) {
    // HTTP API format
    const httpApiIp = event.requestContext?.http?.sourceIp;
    if (httpApiIp) {
        return httpApiIp;
    }
    // REST API format
    if (event.requestContext?.identity?.sourceIp) {
        return event.requestContext.identity.sourceIp;
    }
    // Fallback to X-Forwarded-For header
    const forwardedFor = event.headers?.['X-Forwarded-For'] || event.headers?.['x-forwarded-for'];
    if (forwardedFor) {
        return forwardedFor.split(',')[0]?.trim() || 'Unknown';
    }
    return 'Unknown';
}
/**
 * Get User Agent string
 */
function getUserAgent(event) {
    return (event.headers?.['User-Agent'] ||
        event.headers?.['user-agent'] ||
        'Unknown');
}
/**
 * Create a standardized API response
 */
function createResponse(statusCode, body) {
    return {
        statusCode,
        headers: corsHeaders,
        body: JSON.stringify(body),
    };
}
async function verifyTurnstile(token, ip) {
    try {
        const response = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
                secret: TURNSTILE_SECRET,
                response: token,
                remoteip: ip,
            }),
        });
        const result = (await response.json());
        if (!result.success) {
            console.error('Turnstile verification failed:', result['error-codes']);
        }
        return result.success;
    }
    catch (error) {
        console.error('Turnstile verification error:', error);
        return false;
    }
}
// =============================================================================
// Microsoft Graph Authentication
// =============================================================================
let cachedToken = null;
async function getGraphToken() {
    // Return cached token if still valid (with 5 min buffer)
    if (cachedToken && Date.now() < cachedToken.expiresAt - 300000) {
        return cachedToken.token;
    }
    const msalConfig = {
        auth: {
            clientId: AZURE_CLIENT_ID,
            clientSecret: AZURE_CLIENT_SECRET,
            authority: `https://login.microsoftonline.com/${AZURE_TENANT_ID}`,
        },
    };
    const cca = new msal_node_1.ConfidentialClientApplication(msalConfig);
    const result = await cca.acquireTokenByClientCredential({
        scopes: ['https://graph.microsoft.com/.default'],
    });
    if (!result?.accessToken) {
        throw new Error('Failed to acquire Microsoft Graph access token');
    }
    // Cache the token
    cachedToken = {
        token: result.accessToken,
        expiresAt: result.expiresOn?.getTime() || Date.now() + 3600000,
    };
    return result.accessToken;
}
async function addSubscriber(email, ipAddress, userAgent, source) {
    const token = await getGraphToken();
    const graphBaseUrl = `https://graph.microsoft.com/v1.0/sites/${SHAREPOINT_SITE_ID}/lists/${SHAREPOINT_LIST_ID}`;
    // Check if email already exists
    const checkUrl = `${graphBaseUrl}/items?$filter=fields/Email eq '${email}'&$select=id,fields`;
    const checkResponse = await fetch(checkUrl, {
        headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json',
        },
    });
    if (!checkResponse.ok) {
        const errorText = await checkResponse.text();
        console.error('Error checking existing subscriber:', errorText);
        throw new Error(`Failed to check existing subscriber: ${checkResponse.status}`);
    }
    const checkResult = (await checkResponse.json());
    // If already subscribed, return success with flag
    if (checkResult.value && checkResult.value.length > 0) {
        console.log(`Email ${email} already exists in list`);
        return { success: true, alreadyExists: true };
    }
    // Add new subscriber
    const addUrl = `${graphBaseUrl}/items`;
    const subscribedAt = new Date().toISOString();
    const addResponse = await fetch(addUrl, {
        method: 'POST',
        headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            fields: {
                Title: email, // SharePoint requires Title field
                Email: email,
                IPAddress: ipAddress,
                SubscribedAt: subscribedAt,
                Source: source,
                Status: 'Active',
                UserAgent: userAgent.substring(0, 255), // Limit length for SharePoint
            },
        }),
    });
    if (!addResponse.ok) {
        const errorText = await addResponse.text();
        console.error('Error adding subscriber:', errorText);
        throw new Error(`Failed to add subscriber: ${addResponse.status}`);
    }
    console.log(`Successfully added subscriber: ${email}`);
    return { success: true, alreadyExists: false };
}
// =============================================================================
// Main Lambda Handler
// =============================================================================
async function handler(event) {
    const method = getHttpMethod(event);
    console.log(`Newsletter subscription request: ${method} from ${getClientIp(event)}`);
    // Handle CORS preflight
    if (method === 'OPTIONS') {
        return {
            statusCode: 204,
            headers: corsHeaders,
            body: '',
        };
    }
    // Only allow POST
    if (method !== 'POST') {
        return createResponse(405, {
            success: false,
            error: 'Method not allowed',
        });
    }
    try {
        // Parse request body
        let body;
        try {
            body = JSON.parse(event.body || '{}');
        }
        catch {
            return createResponse(400, {
                success: false,
                error: 'Invalid request body',
            });
        }
        // Validate input
        const validationResult = subscribeSchema.safeParse(body);
        if (!validationResult.success) {
            const firstError = validationResult.error.errors[0];
            return createResponse(400, {
                success: false,
                error: firstError?.message || 'Invalid input',
            });
        }
        const { email, turnstileToken, source } = validationResult.data;
        const clientIp = getClientIp(event);
        const userAgent = getUserAgent(event);
        // Verify Turnstile CAPTCHA
        const turnstileValid = await verifyTurnstile(turnstileToken, clientIp);
        if (!turnstileValid) {
            console.warn(`Turnstile verification failed for ${email} from ${clientIp}`);
            return createResponse(400, {
                success: false,
                error: 'Verification failed. Please try again.',
            });
        }
        // Add subscriber to SharePoint List
        const result = await addSubscriber(email, clientIp, userAgent, source);
        if (result.alreadyExists) {
            return createResponse(200, {
                success: true,
                message: "You're already subscribed!",
            });
        }
        return createResponse(200, {
            success: true,
            message: 'Thanks for subscribing!',
        });
    }
    catch (error) {
        console.error('Newsletter subscription error:', error);
        // Don't expose internal error details to client
        return createResponse(500, {
            success: false,
            error: 'Unable to process subscription. Please try again later.',
        });
    }
}
//# sourceMappingURL=handler.js.map